# 5100p1
Project 1 D3 Visualization

__GitHub Basics:__  
1. Create a local directory named after this repo  
2. ```$ git init``` in /5100p1/  
3. Click the green clone button and copy the https url  
4. ```$ git clone [paste url here]```  
5. After making local changes, add them to the stage ```$ git add .```  
6. Always pull before you commit ```$ git pull```  
7. Commit your changes to your local repo ```$ git commit -m "[describe change here]"```  
8. Push your commit to the remote repo ```$ git push origin master```  

### Authors:
Jiangjie Man, Val Mack, Zhishui Zheng
